import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const CourseDashboardApp());
}

class CourseDashboardApp extends StatelessWidget {
  const CourseDashboardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Course Dashboard',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Navigate to main screen after 3 seconds
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade700,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.school, size: 80, color: Colors.white),
            const SizedBox(height: 24),
            Text(
              'Jeffrey Ntow Botchwey',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),
            Text(
              'University of Energy and Natural Resources',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.white70,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Department of Information Technology\nand Decision Sciences',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.white70,
                  ),
            ),
            const SizedBox(height: 30),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  double _scale = 1.0;

  final List<Map<String, dynamic>> courses = [
    {'name': 'Data Structures and Algorithms', 'instructor': 'Mr. Emmanuel Adjei Domfeh', 'icon': Icons.storage},
    {'name': 'Operating Systems', 'instructor': 'Prof. Vincent Adjei', 'icon': Icons.computer},
    {'name': 'Mobile Development', 'instructor': 'Mr. Emmanuel Botchwey', 'icon': Icons.phone_android},
    {'name': 'IT Auditing', 'instructor': 'Prof. Peter Appiahene', 'icon': Icons.storage_rounded},
    {'name': 'Project Management', 'instructor': 'Dr. Kwabena Adu', 'icon': Icons.engineering},
  ];

  String _selectedCategory = 'Science';

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<void> _showExitDialog() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Exit'),
        content: const Text('Are you sure you want to exit the app?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('No'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Yes'),
          ),
        ],
      ),
    );

    if (result == true) {
      // In real apps: SystemNavigator.pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Exiting app...')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget body;

    switch (_selectedIndex) {
      case 0:
        body = _buildCourses();
        break;
      case 1:
        body = _buildHome();
        break;
      case 2:
        body = _buildProfile();
        break;
      default:
        body = _buildHome();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Course Dashboard'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: _showExitDialog,
          ),
        ],
      ),
      body: SafeArea(
        child: body,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Courses'),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).colorScheme.primary,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildHome() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Home Tab',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          DropdownButton<String>(
            value: _selectedCategory,
            items: const [
              DropdownMenuItem(value: 'Science', child: Text('Science')),
              DropdownMenuItem(value: 'Arts', child: Text('Arts')),
              DropdownMenuItem(value: 'Technology', child: Text('Technology')),
              DropdownMenuItem(value: 'French', child: Text('French')),
              DropdownMenuItem(value: 'African Studies', child: Text('African Studies')),
            ],
            onChanged: (value) {
              setState(() {
                _selectedCategory = value!;
              });
            },
          ),
          const SizedBox(height: 12),
          Text('Selected category: $_selectedCategory'),
          const SizedBox(height: 24),
          AnimatedScale(
            scale: _scale,
            duration: const Duration(milliseconds: 300),
            child: FilledButton.icon(
              icon: const Icon(Icons.add_circle_outline),
              label: const Text('Enroll in a Course'),
              onPressed: () {
                setState(() {
                  _scale = _scale == 1.0 ? 1.2 : 1.0;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Enroll button tapped!')),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCourses() {
    return Column(
      children: [
        const SizedBox(height: 12),
        Text(
          'Courses Tab',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView.separated(
            itemCount: courses.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final course = courses[index];
              return ListTile(
                leading: Icon(course['icon'] as IconData),
                title: Text(course['name']),
                subtitle: Text('Instructor: ${course['instructor']}'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildProfile() {
    return Center(
      child: Text(
        'Profile Tab',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
